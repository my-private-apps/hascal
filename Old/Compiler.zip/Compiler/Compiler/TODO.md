# TODO
- build error reporter
- Write Hascal Standard Libraries (HSL)
- Write Hascal in Hascal 



